module.exports = {
  app: {
    px: "-=",
    token: process.env.TOKEN,
    playing: "music and ;help",
  },
};
