const prettyMilliseconds = require("pretty-ms");

module.exports = (client, int) => {
	if (!int.isButton()) return;

	switch (int.customId) {
		case "btn id": {}
				break;
		case "btn id2": {}
				break;
	}
};
